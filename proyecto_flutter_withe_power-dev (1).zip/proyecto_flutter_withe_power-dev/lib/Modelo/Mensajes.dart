class Mensajes {

/*
  ==================== RUTAS ===============================
*/
  static late String RUTA_LOGIN = "/login";
  static late String RUTA_REGISTROUSUARIO= "/registroUsuario";
  static late String RUTA_REGISTRO_CELULAR_USUARIO= "/registroCelularUsuario";
  static late String RUTA_LOGINUSUARIO= "/loginUsuario";
  static late String RUTA_OLVIDARCONTRASENA1USUARIO= "/olvidarContrasena1";
  static late String RUTA_OLVIDARCONTRASENA2USUARIO= "/olvidarContrasena2";
  static late String RUTA_OLVIDARCONTRASENA3USUARIO= "/olvidarContrasena3";
  static late String RUTA_HOMEIMAGEN1USUARIO= "/homeimagen1";
  static late String RUTA_HOMEIMAGEN2USUARIO= "/homeimagen2";
  static late String RUTA_HOMEIMAGEN3USUARIO= "/homeimagen3";

  static late String RUTA_HOMEUSUARIO= "/home";
  static late String RUTA_EDITUSUARIO= "/editarUsuario";
  static late String RUTA_NOTIFICARUSUARIO= "/notificacion";
  static late String RUTA_ENTRADARUSUARIO= "/entradas";
  static late String RUTA_FAVORITOUSUARIO= "/favorito";
  static late String RUTA_ZONAVIP= "/zonavip";
  static late String RUTA_ZONABOX= "/zonabox";
  static late String RUTA_ZONAGENERAL= "/zonageneral";
  static late String RUTA_DETALLECOMPRA= "/detalleCompra";
/*
  ==================== LOGIN ===============================
*/
  
static late String LOGIN_BIENVENIDA = "Bienvenidos";
static late String LOGIN_INICIARSESION = "Iniciar Sesión";
static late String LOGIN_CREARCUENTA = "Crear una cuenta";

/*
  ==================== CRUD USUARIO ===============================
*/
  static late String CRUD_USUARIO_NOMBRES = "Nombres";
  static late String CRUD_USUARIO_APELLIDOS = "Apellidos";
  static late String CRUD_USUARIO_DNI = "DNI";
  static late String CRUD_USUARIO_GENERO= "Genero";
  static late String CRUD_USUARIO_DIA= "Día";
  static late String CRUD_USUARIO_MES= "Mes";
  static late String CRUD_USUARIO_ANIO= "Año";
}