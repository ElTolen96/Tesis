import 'dart:ui';
import 'package:flutter/material.dart';

String pathProduction = "https://wswhitepower.futprojs.com";
String apiKey = "077c6b8e215715b477754b84846c0f95";

String pathProductionDNI = "https://dniruc.apisperu.com/api/v1/dni";
String pathProductionRUC = "https://dniruc.apisperu.com/api/v1/ruc";
String token = "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJlbWFpbCI6InB1aWNvbjU3QGdtYWlsLmNvbSJ9.wqWe-5LTm4y8Tk6F6Ah0sjJ1vXwS3_xaKGhFZvvE5X4";

const COLOR_FONT_PRIMARY = Color(0xff83a800);
const COLOR_BRAND_PRIMARY = Color(0xff000000);
const COLOR_BRAND_SECONDARY = Color(0xff082739);
const COLOR_CANCEL = Colors.deepOrangeAccent;
const COLOR_INFO = Colors.lightBlue;


String mpTESTPublicKey = "TEST-bb764ba4-1bd1-4daf-9546-beecd82bfcd6";
String mpTESTAccessToken = "TEST-4835615747785929-101513-f3f57bc60c71383dd8037e16514fdf53-1207927907";

String mpPublicKey = "APP_USR-252daaa1-c38c-48b5-bcea-a343f45e641d";
String mpAccessToken = "APP_USR-4835615747785929-101513-5eb2c3b9a7f2260d2771de0aa556c65b-1207927907";

String mpClientID = "4835615747785929";
String mpClientSecret = "S1S5R7MVeMa7wy7ye4CKtXmdDQghJ7yh";

/*----- JHAN ---- */
//String mpPublicKey = "APP_USR-8cae9f67-d342-43fd-9b7e-79a0514419a0";
//String mpAccessToken = "APP_USR-6614644222047642-101912-615de82e5dd81f839d54972ed2b33970-1220834081";

//String mpClientID = "6614644222047642";
//String mpClientSecret = "odrhMtYzbrZQ1960nPU30f9nv6cyLzCe";